Dynamic PyStroke Webpages:

Home: http://127.0.0.1:8000/dynamicpystroke/
Register: http://127.0.0.1:8000/dynamicpystroke/register
Login: http://127.0.0.1:8000/dynamicpystroke/login
Successful Login: http://127.0.0.1:8000/dynamicpystroke/success
Backup Login: http://127.0.0.1:8000/dynamicpystroke/altlogin