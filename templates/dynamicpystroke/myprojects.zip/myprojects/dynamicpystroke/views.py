from django.shortcuts import render
import requests


# Create your views here.


def index(request):
	return render(request, 'dynamicpystroke/index.html')

def button(request):
	return render(request, 'index.html')

#def output(request):
#	data=requests.get("https://www.google.com")
#	print(data.text)
#	data=data.text
#	return render(request, 'index.html', {'data':data})



def register(request):
	return render(request, 'dynamicpystroke/register.html')


def login(request):
	return render(request, 'dynamicpystroke/login.html')

def success(request):
	return render(request, 'dynamicpystroke/success.html')

def altlogin(request):
	return render(request, 'dynamicpystroke/altlogin.html')