import datetime
import pytest


class BankAccount:
    def __init__(self, name='Rumbi Gwanz', id='123', creation_date:datetime.date=datetime.date.today(), balance=0):
        self.name = name
        self.id = id
        self.balance = balance
        if creation_date <= datetime.date.today():
            self.creation_date = creation_date
        else:
            raise Exception('Account creation date cannot be in the future')

    def deposit(self, amount):
        self.balance += amount
        return self.balance         

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance -= amount
            return self.balance
        else:
            raise Exception('You have Insufficient funds')

    def view_balance(self):
        return self.balance


#Savings Account

class SavingsAccount(BankAccount):
    def withdraw(self,amount):
        withdraw_date = datetime.date.today()
        date = withdraw_date - self.creation_date
        if date.days <= 30*6:
           raise Exception('Withdrawals are only allowed after 6 months of account creation')
        elif date.days > 30*6 and amount > self.balance:
           raise Exception('You cannot overdraft')
        else:
           self.balance -= amount
           return self.balance

#Checking Account

class CheckingAccount(BankAccount):
    def withdraw(self, amount):
        if amount > self.balance:
           self.balance -= (amount + 30)
        else:
           self.balance -= amount
        return self.balance


person1 = BankAccount('Rumbi Gwanz', '123', datetime.date(2018,1,3), 5000)
print(person1.view_balance())

Ben = BankAccount('Ben Minikwu', '626', datetime.date(2018,1,3), 5000)
Ben.withdraw(500)
print(Ben)


#-----------------------------------tests---------------------------------
    
#test 1 - test_constructor for BankAccount

def test_constructor():
    with pytest.raises(Exception):
        BankAccount('Ben Minikwu', '626', datetime.date(2020,1,1), 5000)

#test 2 - test_savings_update
        
def test_savings_update():
    account = SavingsAccount('Ben Minikwu', '626', datetime.date(2018,1,1), 5000)
    account.withdraw(2000)
    assert acccount.balance == 3000

#test 3 - test_savings_negative
    
def test_savings_negative():
    account = SavingsAccount('Ben Minikwu', '626', datetime.date(2018,1,1), 5000)
    account.withdraw(5500)
    assert account.balance == 5000

#test 4 - test_savings_young_account
    
def test_savings_young_account():
    account = SavingsAccount('Ben Minikwu', '626', datetime.date(2019,9,29), 5000)
    account.withdraw(2000)
    assert account.balance == 3000

#test 5 - test_checking_deposit
    
def test_checking_deposit():
    account = CheckingAccount('Ben Minikwu', '626', datetime.date(2018,1,1), 5000)
    account.deposit(500)
    assert account.balance == 5500

#test 6 - test_checking_withdraw

def test_checking_withdraw():
    account = CheckingAccount('Ben Minikwu', '626', datetime.date(2018,1,1), 5000)
    account.withdraw(500)
    assert account.balance == 4500

#test 7 - test_checking_overdraft

def test_checking_overdraft():
    account = CheckingAccount('Ben Minikwu', '626', datetime.date(2018,1,1), 5000)
    account.withdraw(5200)
    assert account.balance == -200
    
