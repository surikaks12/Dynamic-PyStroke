Extract the django folder

Launch your command line: pip install django

cd into the django\myproject directory > python manage.py runserver

copy and paste into web browser: http://127.0.0.1:8000/dynamicpystroke/