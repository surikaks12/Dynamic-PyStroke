from django.apps import AppConfig


class DynamicpystrokeConfig(AppConfig):
    name = 'dynamicpystroke'
